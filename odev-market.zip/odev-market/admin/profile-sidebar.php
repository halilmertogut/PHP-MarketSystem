<ul class='profile-menu'>
    <li><a href='./profile.php'>Profile Update</a></li>
    <li><a href='./logout.php'>Logout</a></li>
</ul>